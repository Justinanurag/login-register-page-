const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/mernstackReg")
.then(() => {
  console.log("✅ MongoDB Connection Successful");
})
.catch((err) => {
  console.error("❌ MongoDB Connection Error:", err);
});
