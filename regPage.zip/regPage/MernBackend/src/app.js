const express = require('express');
const path = require('path');
const app = express();
const hbs = require('hbs');
const session = require('express-session');
const Register = require('./models/registers');
require('./db/conn');

const PORT = 4000;
const staticPath = path.join(__dirname, "../public");
const templatesPath = path.join(__dirname, "../templates/views");
const partialsPath = path.join(__dirname, "../templates/partials");

// Middleware setup
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(staticPath));
app.set('view engine', 'hbs');
app.set('views', templatesPath);
hbs.registerPartials(partialsPath);

// Session middleware setup
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } // set to true if using https
}));

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
    if (req.session.userId) {
        next();
    } else {
        res.redirect('/login');
    }
};

// Routes
app.get('/', (req, res) => {
    if (req.session.userId) {
        res.redirect('/welcome');
    } else {
        res.redirect('/login');
    }
});

app.get('/register', (req, res) => {
    res.render('register');
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/register', async (req, res) => {
    try {
        const { fullname: fullName, email: emailAddress, phone: phoneNumber, password, confirmpassword } = req.body;
        
        if(password !== confirmpassword) {
            return res.status(400).render('register', {
                error: "Passwords do not match",
                fullname: fullName,
                email: emailAddress,
                phone: phoneNumber
            });
        }

        // Check if user already exists
        const existingUser = await Register.findOne({ emailAddress });
        if (existingUser) {
            return res.status(400).render('register', {
                error: "Email already registered",
                fullname: fullName,
                phone: phoneNumber
            });
        }

        // Create new user
        const user = new Register({
            fullName,
            emailAddress,
            phoneNumber,
            password
        });

        await user.save();
        res.redirect('/login');
    } catch (error) {
        res.status(400).render('register', {
            error: "Registration failed. Please try again.",
            ...req.body
        });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { email: emailAddress, password } = req.body;
        
        // Find user by email
        const user = await Register.findOne({ emailAddress });
        if (!user) {
            return res.status(401).render('login', {
                error: "This email is not registered. Please create an account first.",
                email: emailAddress
            });
        }

        // Verify password
        const isValidPassword = await user.comparePassword(password);
        if (!isValidPassword) {
            return res.status(401).render('login', {
                error: "Incorrect password. Please try again.",
                email: emailAddress
            });
        }

        // Set user session
        req.session.userId = user._id;
        res.redirect('/welcome');
    } catch (error) {
        res.status(400).render('login', {
            error: "Login failed. Please try again.",
            email: req.body.email
        });
    }
});

app.get('/welcome', isAuthenticated, async (req, res) => {
    try {
        const user = await Register.findById(req.session.userId);
        if (!user) {
            return res.redirect('/login');
        }
        res.render('welcome', { user });
    } catch (error) {
        res.redirect('/login');
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.redirect('/welcome');
        }
        res.redirect('/login');
    });
});

app.listen(PORT, () => {
    console.log(`✅ Server is running on http://localhost:${PORT}`);
});